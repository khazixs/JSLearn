

var substates=[
    {
        "name": "中间节点-48",
        "gps": [
            112.974829,
            28.160667
        ]
    },
    {
        "name": "黄土岭",
        "gps": [
            112.985699,
            28.160186
        ]
    },
    {
        "name": "砂子塘",
        "gps": [
            112.994325,
            28.162467
        ]
    },
    {
        "name": "中间节点-49",
        "gps": [
            113.002835,
            28.162344
        ]
    },
    {
        "name": "赤岗岭",
        "gps": [
            113.004855,
            28.160271
        ]
    },
    {
        "name": "中间节点-50",
        "gps": [
            113.005539,
            28.157648
        ]
    },
    {
        "name": "树木岭",
        "gps": [
            113.018854,
            28.155667
        ]
    },
    {
        "name": "圭塘",
        "gps": [
            113.029166,
            28.157539
        ]
    },
    {
        "name": "沙湾公园",
        "gps": [
            113.044484,
            28.157908
        ]
    },
    {
        "name": "粟塘",
        "gps": [
            113.052052,
            28.157773
        ]
    },
    {
        "name": "中间节点-51",
        "gps": [
            113.056172,
            28.157471
        ]
    },
    {
        "name": "平阳",
        "gps": [
            113.057063,
            28.151782
        ]
    },
    {
        "name": "中间节点-52",
        "gps": [
            113.058025,
            28.146667
        ]
    },
    {
        "name": "长沙火车南站",
        "gps": [
            113.064789,
            28.146456
        ]
    },
    {
        "name": "光达",
        "gps": [
            113.084938,
            28.148158
        ]
    },
    {
        "name": "中间节点-13",
        "gps": [
            113.090169,
            28.147577
        ]
    },
    {
        "name": "杜家坪",
        "gps": [
            113.090517,
            28.137067
        ]
    },
    {
        "name": "广生",
        "gps": [
            113.131299,
            28.245493
        ]
    },
    {
        "name": "螺丝塘",
        "gps": [
            113.123034,
            28.245509
        ]
    },
    {
        "name": "星沙文体中心",
        "gps": [
            113.111496,
            28.24554
        ]
    },
    {
        "name": "松雅湖（南）",
        "gps": [
            113.102607,
            28.245565
        ]
    },
    {
        "name": "星沙",
        "gps": [
            113.085704,
            28.245924
        ]
    },
    {
        "name": "湘龙",
        "gps": [
            113.059008,
            28.245808
        ]
    },
    {
        "name": "中间节点-26",
        "gps": [
            113.051738,
            28.24737
        ]
    },
    {
        "name": "中间节点-27",
        "gps": [
            113.051523,
            28.247273
        ]
    },
    {
        "name": "中间节点-28",
        "gps": [
            113.046535,
            28.242363
        ]
    },
    {
        "name": "月湖公园北",
        "gps": [
            113.040862,
            28.242185
        ]
    },
    {
        "name": "长沙大学",
        "gps": [
            113.031583,
            28.241072
        ]
    },
    {
        "name": "中间节点-29",
        "gps": [
            113.020916,
            28.240718
        ]
    },
    {
        "name": "中间节点-30",
        "gps": [
            113.019039,
            28.237596
        ]
    },
    {
        "name": "雅雀湖",
        "gps": [
            113.013807,
            28.237461
        ]
    },
    {
        "name": "中间节点-31",
        "gps": [
            113.007491,
            28.237221
        ]
    },
    {
        "name": "四方坪",
        "gps": [
            113.006731,
            28.230743
        ]
    },
    {
        "name": "丝茅冲",
        "gps": [
            113.006877,
            28.22393
        ]
    },
    {
        "name": "烈士公园东",
        "gps": [
            113.008909,
            28.20741
        ]
    },
    {
        "name": "中间节点-32",
        "gps": [
            113.008909,
            28.20741
        ]
    },
    {
        "name": "长沙火车站",
        "gps": [
            113.010853,
            28.193771
        ]
    },
    {
        "name": "朝阳村",
        "gps": [
            113.01078,
            28.185035
        ]
    },
    {
        "name": "阿弥岭",
        "gps": [
            113.01009,
            28.175465
        ]
    },
    {
        "name": "中间节点-33",
        "gps": [
            113.008899,
            28.173671
        ]
    },
    {
        "name": "桂花公园",
        "gps": [
            113.000997,
            28.170557
        ]
    },
    {
        "name": "东塘",
        "gps": [
            112.99411,
            28.169507
        ]
    },
    {
        "name": "侯家塘",
        "gps": [
            112.981907,
            28.173893
        ]
    },
    {
        "name": "中间节点-34",
        "gps": [
            112.975081,
            28.178309
        ]
    },
    {
        "name": "灵官渡",
        "gps": [
            112.970632,
            28.179268
        ]
    },
    {
        "name": "中间节点-35",
        "gps": [
            112.953732,
            28.174163
        ]
    },
    {
        "name": "中间节点-36",
        "gps": [
            112.948795,
            28.169427
        ]
    },
    {
        "name": "阜埠河",
        "gps": [
            112.948401,
            28.165471
        ]
    },
    {
        "name": "中间节点-37",
        "gps": [
            112.948113,
            28.160116
        ]
    },
    {
        "name": "中间节点-38",
        "gps": [
            112.939416,
            28.157008
        ]
    },
    {
        "name": "中南大学",
        "gps": [
            112.937911,
            28.154884
        ]
    },
    {
        "name": "阳光",
        "gps": [
            112.936823,
            28.13945
        ]
    },
    {
        "name": "中间节点-39",
        "gps": [
            112.938144,
            28.136156
        ]
    },
    {
        "name": "中间节点-40",
        "gps": [
            112.943081,
            28.133429
        ]
    },
    {
        "name": "洋湖新城",
        "gps": [
            112.944902,
            28.129892
        ]
    },
    {
        "name": "洋湖湿地",
        "gps": [
            112.938451,
            28.114272
        ]
    },
    {
        "name": "山塘",
        "gps": [
            112.924619,
            28.097091
        ]
    },
    {
        "name": "光达",
        "gps": [
            113.084938,
            28.148158
        ]
    },
    {
        "name": "长沙火车南站",
        "gps": [
            113.064789,
            28.146456
        ]
    },
    {
        "name": "杜花路",
        "gps": [
            113.056306,
            28.146293
        ]
    },
    {
        "name": "中间节点-14",
        "gps": [
            113.054694,
            28.146208
        ]
    },
    {
        "name": "中间节点-15",
        "gps": [
            113.044983,
            28.152814
        ]
    },
    {
        "name": "沙湾公园",
        "gps": [
            113.044484,
            28.157908
        ]
    },
    {
        "name": "长沙大道",
        "gps": [
            113.044488,
            28.168354
        ]
    },
    {
        "name": "中间节点-16",
        "gps": [
            113.044129,
            28.170613
        ]
    },
    {
        "name": "中间节点-17",
        "gps": [
            113.038596,
            28.17637
        ]
    },
    {
        "name": "人民东路",
        "gps": [
            113.038735,
            28.184296
        ]
    },
    {
        "name": "中间节点-18",
        "gps": [
            113.038801,
            28.191299
        ]
    },
    {
        "name": "万家丽广场",
        "gps": [
            113.03031,
            28.191564
        ]
    },
    {
        "name": "锦泰广场",
        "gps": [
            113.017982,
            28.192041
        ]
    },
    {
        "name": "长沙火车站",
        "gps": [
            113.010853,
            28.193771
        ]
    },
    {
        "name": "中间节点-19",
        "gps": [
            113.009743,
            28.194101
        ]
    },
    {
        "name": "袁家岭",
        "gps": [
            113.000803,
            28.194428
        ]
    },
    {
        "name": "迎宾路口",
        "gps": [
            112.991934,
            28.194887
        ]
    },
    {
        "name": "芙蓉广场",
        "gps": [
            112.984122,
            28.19496
        ]
    },
    {
        "name": "五一广场",
        "gps": [
            112.976414,
            28.195344
        ]
    },
    {
        "name": "湘江中路",
        "gps": [
            112.969257,
            28.195171
        ]
    },
    {
        "name": "橘子洲",
        "gps": [
            112.962378,
            28.195312
        ]
    },
    {
        "name": "中间节点-20",
        "gps": [
            112.962378,
            28.195312
        ]
    },
    {
        "name": "荣湾镇",
        "gps": [
            112.951282,
            28.197596
        ]
    },
    {
        "name": "中间节点-21",
        "gps": [
            112.950208,
            28.198802
        ]
    },
    {
        "name": "西湖公园",
        "gps": [
            112.940114,
            28.202576
        ]
    },
    {
        "name": "中间节点-22",
        "gps": [
            112.933668,
            28.202918
        ]
    },
    {
        "name": "金星路",
        "gps": [
            112.928593,
            28.206051
        ]
    },
    {
        "name": "中间节点-23",
        "gps": [
            112.925291,
            28.207415
        ]
    },
    {
        "name": "望城坡",
        "gps": [
            112.913971,
            28.207403
        ]
    },
    {
        "name": "中间节点-24",
        "gps": [
            112.90787,
            28.205766
        ]
    },
    {
        "name": "梅溪湖东",
        "gps": [
            112.908144,
            28.20142
        ]
    },
    {
        "name": "中间节点-25",
        "gps": [
            112.908417,
            28.198982
        ]
    },
    {
        "name": "文化艺术中心",
        "gps": [
            112.900471,
            28.196633
        ]
    },
    {
        "name": "麓云路",
        "gps": [
            112.892268,
            28.190786
        ]
    },
    {
        "name": "梅溪湖西",
        "gps": [
            112.881591,
            28.185543
        ]
    },
    {
        "name": "开福区政府",
        "gps": [
            112.985809,
            28.261942
        ]
    },
    {
        "name": "马厂",
        "gps": [
            112.988714,
            28.251134
        ]
    },
    {
        "name": "中间节点-0",
        "gps": [
            112.990222,
            28.245934
        ]
    },
    {
        "name": "北辰三角洲",
        "gps": [
            112.983775,
            28.235887
        ]
    },
    {
        "name": "中间节点-1",
        "gps": [
            112.980628,
            28.062612
        ]
    },
    {
        "name": "中间节点-2",
        "gps": [
            112.979057,
            28.062612
        ]
    },
    {
        "name": "开福寺",
        "gps": [
            112.979309,
            28.062612
        ]
    },
    {
        "name": "中间节点-3",
        "gps": [
            112.979939,
            28.062612
        ]
    },
    {
        "name": "文昌阁",
        "gps": [
            112.978228,
            28.062612
        ]
    },
    {
        "name": "培元桥",
        "gps": [
            112.976493,
            28.062612
        ]
    },
    {
        "name": "中间节点-4",
        "gps": [
            112.975867,
            28.062612
        ]
    },
    {
        "name": "五一广场",
        "gps": [
            112.976414,
            28.062612
        ]
    },
    {
        "name": "黄兴广场",
        "gps": [
            112.976402,
            28.062612
        ]
    },
    {
        "name": "南门口",
        "gps": [
            112.976065,
            28.062612
        ]
    },
    {
        "name": "中间节点-5",
        "gps": [
            112.975888,
            28.062612
        ]
    },
    {
        "name": "中间节点-6",
        "gps": [
            112.97684,
            28.062612
        ]
    },
    {
        "name": "中间节点-7",
        "gps": [
            112.978618,
            28.062612
        ]
    },
    {
        "name": "侯家塘",
        "gps": [
            112.981907,
            28.062612
        ]
    },
    {
        "name": "中间节点-8",
        "gps": [
            112.985036,
            28.062612
        ]
    },
    {
        "name": "南湖路",
        "gps": [
            112.985773,
            28.062612
        ]
    },
    {
        "name": "黄土岭",
        "gps": [
            112.985699,
            28.062612
        ]
    },
    {
        "name": "中间节点-9",
        "gps": [
            112.98406,
            28.062612
        ]
    },
    {
        "name": "涂家冲",
        "gps": [
            112.984633,
            28.062612
        ]
    },
    {
        "name": "中间节点-10",
        "gps": [
            112.985225,
            28.062612
        ]
    },
    {
        "name": "中间节点-11",
        "gps": [
            112.985411,
            28.062612
        ]
    },
    {
        "name": "铁道学院",
        "gps": [
            112.987378,
            28.062612
        ]
    },
    {
        "name": "友谊路",
        "gps": [
            112.986837,
            28.062612
        ]
    },
    {
        "name": "省政府",
        "gps": [
            112.987444,
            28.062612
        ]
    },
    {
        "name": "桂花坪",
        "gps": [
            112.988311,
            28.062612
        ]
    },
    {
        "name": "大托",
        "gps": [
            112.989261,
            28.062612
        ]
    },
    {
        "name": "中信广场",
        "gps": [
            112.989684,
            28.062612
        ]
    },
    {
        "name": "中间节点-12",
        "gps": [
            112.989814,
            28.062612
        ]
    },
    {
        "name": "尚双塘",
        "gps": [
            112.99216,
            28.062612
        ]
    }
]

var sublines = [
    [
        {
            "name": "中间节点-48",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "黄土岭",
            "value": 30
        }
    ],
    [
        {
            "name": "黄土岭",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "砂子塘",
            "value": 30
        }
    ],
    [
        {
            "name": "砂子塘",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-49",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-49",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "赤岗岭",
            "value": 30
        }
    ],
    [
        {
            "name": "赤岗岭",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-50",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-50",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "树木岭",
            "value": 30
        }
    ],
    [
        {
            "name": "树木岭",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "圭塘",
            "value": 30
        }
    ],
    [
        {
            "name": "圭塘",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "沙湾公园",
            "value": 30
        }
    ],
    [
        {
            "name": "沙湾公园",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "粟塘",
            "value": 30
        }
    ],
    [
        {
            "name": "粟塘",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-51",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-51",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "平阳",
            "value": 30
        }
    ],
    [
        {
            "name": "平阳",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-52",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-52",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "长沙火车南站",
            "value": 30
        }
    ],
    [
        {
            "name": "长沙火车南站",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "光达",
            "value": 30
        }
    ],
    [
        {
            "name": "光达",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-13",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-13",
            "linename": "四号线",
            "smoothness": 0
        },
        {
            "name": "杜家坪",
            "value": 30
        }
    ],
    [
        {
            "name": "广生",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "螺丝塘",
            "value": 30
        }
    ],
    [
        {
            "name": "螺丝塘",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "星沙文体中心",
            "value": 30
        }
    ],
    [
        {
            "name": "星沙文体中心",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "松雅湖（南）",
            "value": 30
        }
    ],
    [
        {
            "name": "松雅湖（南）",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "星沙",
            "value": 30
        }
    ],
    [
        {
            "name": "星沙",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "湘龙",
            "value": 30
        }
    ],
    [
        {
            "name": "湘龙",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-26",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-26",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-27",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-27",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-28",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-28",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "月湖公园北",
            "value": 30
        }
    ],
    [
        {
            "name": "月湖公园北",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "长沙大学",
            "value": 30
        }
    ],
    [
        {
            "name": "长沙大学",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-29",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-29",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-30",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-30",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "雅雀湖",
            "value": 30
        }
    ],
    [
        {
            "name": "雅雀湖",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-31",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-31",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "四方坪",
            "value": 30
        }
    ],
    [
        {
            "name": "四方坪",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "丝茅冲",
            "value": 30
        }
    ],
    [
        {
            "name": "丝茅冲",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "烈士公园东",
            "value": 30
        }
    ],
    [
        {
            "name": "烈士公园东",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-32",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-32",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "长沙火车站",
            "value": 30
        }
    ],
    [
        {
            "name": "长沙火车站",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "朝阳村",
            "value": 30
        }
    ],
    [
        {
            "name": "朝阳村",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "阿弥岭",
            "value": 30
        }
    ],
    [
        {
            "name": "阿弥岭",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-33",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-33",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "桂花公园",
            "value": 30
        }
    ],
    [
        {
            "name": "桂花公园",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "东塘",
            "value": 30
        }
    ],
    [
        {
            "name": "东塘",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "侯家塘",
            "value": 30
        }
    ],
    [
        {
            "name": "侯家塘",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-34",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-34",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "灵官渡",
            "value": 30
        }
    ],
    [
        {
            "name": "灵官渡",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-35",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-35",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-36",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-36",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "阜埠河",
            "value": 30
        }
    ],
    [
        {
            "name": "阜埠河",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-37",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-37",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-38",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-38",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中南大学",
            "value": 30
        }
    ],
    [
        {
            "name": "中南大学",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "阳光",
            "value": 30
        }
    ],
    [
        {
            "name": "阳光",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-39",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-39",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-40",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-40",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "洋湖新城",
            "value": 30
        }
    ],
    [
        {
            "name": "洋湖新城",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "洋湖湿地",
            "value": 30
        }
    ],
    [
        {
            "name": "洋湖湿地",
            "linename": "三号线",
            "smoothness": 0
        },
        {
            "name": "山塘",
            "value": 30
        }
    ],
    [
        {
            "name": "光达",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "长沙火车南站",
            "value": 30
        }
    ],
    [
        {
            "name": "长沙火车南站",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "杜花路",
            "value": 30
        }
    ],
    [
        {
            "name": "杜花路",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-14",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-14",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-15",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-15",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "沙湾公园",
            "value": 30
        }
    ],
    [
        {
            "name": "沙湾公园",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "长沙大道",
            "value": 30
        }
    ],
    [
        {
            "name": "长沙大道",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-16",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-16",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-17",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-17",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "人民东路",
            "value": 30
        }
    ],
    [
        {
            "name": "人民东路",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-18",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-18",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "万家丽广场",
            "value": 30
        }
    ],
    [
        {
            "name": "万家丽广场",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "锦泰广场",
            "value": 30
        }
    ],
    [
        {
            "name": "锦泰广场",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "长沙火车站",
            "value": 30
        }
    ],
    [
        {
            "name": "长沙火车站",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-19",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-19",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "袁家岭",
            "value": 30
        }
    ],
    [
        {
            "name": "袁家岭",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "迎宾路口",
            "value": 30
        }
    ],
    [
        {
            "name": "迎宾路口",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "芙蓉广场",
            "value": 30
        }
    ],
    [
        {
            "name": "芙蓉广场",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "五一广场",
            "value": 30
        }
    ],
    [
        {
            "name": "五一广场",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "湘江中路",
            "value": 30
        }
    ],
    [
        {
            "name": "湘江中路",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "橘子洲",
            "value": 30
        }
    ],
    [
        {
            "name": "橘子洲",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-20",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-20",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "荣湾镇",
            "value": 30
        }
    ],
    [
        {
            "name": "荣湾镇",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-21",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-21",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "西湖公园",
            "value": 30
        }
    ],
    [
        {
            "name": "西湖公园",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-22",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-22",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "金星路",
            "value": 30
        }
    ],
    [
        {
            "name": "金星路",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-23",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-23",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "望城坡",
            "value": 30
        }
    ],
    [
        {
            "name": "望城坡",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-24",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-24",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "梅溪湖东",
            "value": 30
        }
    ],
    [
        {
            "name": "梅溪湖东",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-25",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-25",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "文化艺术中心",
            "value": 30
        }
    ],
    [
        {
            "name": "文化艺术中心",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "麓云路",
            "value": 30
        }
    ],
    [
        {
            "name": "麓云路",
            "linename": "二号线",
            "smoothness": 0
        },
        {
            "name": "梅溪湖西",
            "value": 30
        }
    ],
    [
        {
            "name": "开福区政府",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "马厂",
            "value": 30
        }
    ],
    [
        {
            "name": "马厂",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-0",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-0",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "北辰三角洲",
            "value": 30
        }
    ],
    [
        {
            "name": "北辰三角洲",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-1",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-1",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-2",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-2",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "开福寺",
            "value": 30
        }
    ],
    [
        {
            "name": "开福寺",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-3",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-3",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "文昌阁",
            "value": 30
        }
    ],
    [
        {
            "name": "文昌阁",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "培元桥",
            "value": 30
        }
    ],
    [
        {
            "name": "培元桥",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-4",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-4",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "五一广场",
            "value": 30
        }
    ],
    [
        {
            "name": "五一广场",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "黄兴广场",
            "value": 30
        }
    ],
    [
        {
            "name": "黄兴广场",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "南门口",
            "value": 30
        }
    ],
    [
        {
            "name": "南门口",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-5",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-5",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-6",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-6",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-7",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-7",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "侯家塘",
            "value": 30
        }
    ],
    [
        {
            "name": "侯家塘",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-8",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-8",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "南湖路",
            "value": 30
        }
    ],
    [
        {
            "name": "南湖路",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "黄土岭",
            "value": 30
        }
    ],
    [
        {
            "name": "黄土岭",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-9",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-9",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "涂家冲",
            "value": 30
        }
    ],
    [
        {
            "name": "涂家冲",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-10",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-10",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-11",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-11",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "铁道学院",
            "value": 30
        }
    ],
    [
        {
            "name": "铁道学院",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "友谊路",
            "value": 30
        }
    ],
    [
        {
            "name": "友谊路",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "省政府",
            "value": 30
        }
    ],
    [
        {
            "name": "省政府",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "桂花坪",
            "value": 30
        }
    ],
    [
        {
            "name": "桂花坪",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "大托",
            "value": 30
        }
    ],
    [
        {
            "name": "大托",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中信广场",
            "value": 30
        }
    ],
    [
        {
            "name": "中信广场",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "中间节点-12",
            "value": 30
        }
    ],
    [
        {
            "name": "中间节点-12",
            "linename": "一号线",
            "smoothness": 0
        },
        {
            "name": "尚双塘",
            "value": 30
        }
    ]
]
let a = [1,2,4];
a.unshift(10);
console.log(a)

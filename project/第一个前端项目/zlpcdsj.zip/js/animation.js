window.onload = function(){

    let oDivMap = document.getElementById('map');
    creatCurrentData()
    creatShakeData();
    let a = 0;
    let b = 0;


    let newTimer= setInterval(function () {
      number1 += 1;
  creatCurrentData();
},1000);//5000ms刷新一次



  let newTimer1= setInterval(function () {
    number2 += 1;
      creatShakeData();

},1000);//1000ms刷新一次




    oDivMap.onclick = function(){
      number2 = Math.ceil(Math.random()*2000);
      console.log(nowData)
      if(nowData[0] == '500 kv'||nowData[0] == '220 kv'||nowData[0] == '110 kv'||nowData[0] == '35 kv'){
        if(nowData[2] !== 0){
          powerName = nowData[1];
          option1.title.text = powerName + '当前时间十分钟以内时间电流曲线';
          option2.title.text = powerName + '当前时间两分钟以内时间震动曲线';
           creatCurrentData();
           creatShakeData();
        }else{
          console.log('不是变电站')
        }
      }
    }
}


function creatCurrentData(){
let currentArray1 = [];
let timeArray1 = [];
for (k in timeCurrent){
  if(timeCurrent[k]['name'] == powerName){
    if(number1 < 2980){
      for(let i = number1 ;i < (number1+120);i++){
          currentArray1.push(timeCurrent[k]['current'][i])
      }
    }else{
      number1 = 0;
      for(let i = number1 ;i < (number1+120);i++){
          currentArray1.push(timeCurrent[k]['current'][i])
      }
    }
  }
}
let timer = new Date();
let hour = timer.getHours();
let minutes = timer.getMinutes();
let seconds = timer.getSeconds();
let result = hour.toString() + addZero(minutes) + addZero(seconds);
result = parseInt(result);
for(let i = (result - 120);i < result;i++){
  timeArray1.push(i);
}
timeArray = timeArray1;
currentArray = currentArray1
option1.xAxis.data=timeArray;
option1.series[0].data = currentArray;
lineChart.setOption(option1);
}



function creatShakeData(){
if(number2>=60000){
number2 = 0;
}
let shakeArray1 = [];
let timeArray1 = [];
for(let i = number2;i<number2 + 120;i++){
shakeArray1.push(shake[i]);
}
let timer = new Date();
let hour = timer.getHours();
let minutes = timer.getMinutes();
let seconds = timer.getSeconds();
let result = hour.toString() + addZero(minutes) + addZero(seconds);
result = parseInt(result);
for(let i = (result - 120);i < result;i++){
timeArray1.push(i);
}
timeArray = timeArray1;
shakeArray = shakeArray1;
option2.xAxis.data=timeArray;
option2.series[0].data = shakeArray;
histogram.setOption(option2);

}

function addZero(value) {
    if (value < 10) {
        return "0" + value
    } else {
        return '' + value
    }
  }

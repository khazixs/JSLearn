


var geocoord={};
var powersub500={};
var powersub220={};
var powersub110={};
var powersub35={};
var mapSeries = [];
var point500=[];
var point220=[];
var point110=[];
var point35=[];
var geo500={
    "长沙市": {},
    "株洲市": {},
    "湘潭市": {},
    "衡阳市": {},
    "邵阳市": {},
    "岳阳市": {},
    "常德市": {},
    "张家界市": {},
    "益阳市": {},
    "郴州市": {},
    "永州市": {},
    "怀化市": {},
    "娄底市": {},
    "湘西土家族苗族自治州": {}
};
var geo220={
    "长沙市": {},
    "株洲市": {},
    "湘潭市": {},
    "衡阳市": {},
    "邵阳市": {},
    "岳阳市": {},
    "常德市": {},
    "张家界市": {},
    "益阳市": {},
    "郴州市": {},
    "永州市": {},
    "怀化市": {},
    "娄底市": {},
    "湘西土家族苗族自治州": {}
};
var geo110={
    "成都市": {},
    "自贡市": {},
    "攀枝花市": {},
    "泸州市": {},
    "德阳市": {},
    "绵阳市": {},
    "广元市": {},
    "遂宁市": {},
    "内江市": {},
    "乐山市": {},
    "南充市": {},
    "眉山市": {},
    "宜宾市": {},
    "广安市": {},
    "达州市": {},
    "雅安市": {},
    "巴中市": {},
    "资阳市": {},
    "阿坝藏族羌族自治州": {},
    "甘孜藏族自治州": {},
    "凉山彝族自治州": {}
};
var geo35={
    "成都市": {},
    "自贡市": {},
    "攀枝花市": {},
    "泸州市": {},
    "德阳市": {},
    "绵阳市": {},
    "广元市": {},
    "遂宁市": {},
    "内江市": {},
    "乐山市": {},
    "南充市": {},
    "眉山市": {},
    "宜宾市": {},
    "广安市": {},
    "达州市": {},
    "雅安市": {},
    "巴中市": {},
    "资阳市": {},
    "阿坝藏族羌族自治州": {},
    "甘孜藏族自治州": {},
    "凉山彝族自治州": {}
};

var totalname = [];

powersub500=gps["500kV"];
// console.log(powersub500);
powersub220=gps["220kV"];
powersub110=gps["110kV"];
powersub35=gps["35kV"];

for(var key in powersub500){
    var temp500=powersub500[key];
    // console.log(temp500);
    //var name500=temp500["设备名称"];
    var gps500=temp500["gps"];
    var city500=temp500["city"];
    geocoord[key]=gps500;
    geo500[city500][key]=gps500;
    totalname.push(key);
    // heatPoint500.push(temp500["gps"]);
    // heatPoint500.push(0);
    var point={
        name:key
    };
    point500.push(point);
    // console.log(geocoord);
}
//console.log(point500);
for(var key in powersub220){
    var temp220=powersub220[key];
    //var name220=temp220["设备名称"];
    var gps220=temp220["gps"];
    geocoord[key]=gps220;
    var city220=temp220["city"];
    geo220[city220][key]=gps220;
    totalname.push(key);
    // heatPoint220.push(temp220["gps"]);
    // heatPoint220.push(0);
    var point={
        name:key
    };
    point220.push(point);
}
//for(var key in powersub110){
//    var temp110=powersub110[key];
//    //var name110=temp110["设备名称"];
//    var gps110=temp110["gps"];
//    geocoord[key]=gps110;
//    var city110=temp110["city"];
//    geo110[city110][key]=gps110;
//    totalname.push(key);
//    // heatPoint110.push(temp110["gps"]);
//    // heatPoint110.push(0);
//    var point={
//        name:key
//    };
//    point110.push(point);
//}
//for(var key in powersub35){
//    var temp35=powersub35[key];
//    //var name35=temp35["设备名称"];
//    var gps35=temp35["gps"];
//    geocoord[key]=gps35;
//    var city35=temp35["city"];
//    geo35[city35][key]=gps35;
//    totalname.push(key);
//    // heatPoint35.push(temp35["gps"]);
//    // heatPoint35.push(0);
//    var point={
//        name:key
//    };
//    point35.push(point);
//}
//geocoord["500kV"]=geo500;
//geocoord["220kV"]=geo220;
//geocoord["110kV"]=geo110;
//geocoord["35kV"]=geo35;
//请求1分钟断面数据
var pmudata = {};
//地图点部分
function optionMapSeries(seriesName,seriesMarkPoint,linePoint){

    return {
        name:seriesName,
        type:'map',
        mapType:'湖南',
        hoverable:false,
        roam:true,
        mapLocation:{x:"center",y:'center'},

        itemStyle: {
            normal: {
                label:{
                    show:true,
                    textStyle:{
                        // color:'#ffffff',
                        fontFamily:"Microsoft Yahei"
                    }
                },
                // 地图边框
                // borderColor: 'rgba(64,224,208,1)',
                // borderColor: '#ddfc52',
                areaStyle:{
                    // color: 'rgba(0,0,0,1)'
                }
            },
            emphasis: {
                label:{
                    show:false,
                    textStyle:{
                        // color:'#02DF82',
                        fontFamily:"Microsoft Yahei"
                    }
                },
                borderColor: 'rgba(255,255,255,1)',
                areaStyle:{
                    // color: 'rgba(0, 0, 0, 0.9)'
                }
            }
        },
        geoCoord:geocoord,
        // // 文本位置修正.
        // textFixed : {
        //     '崇州市' : [0, -50],
        //     '达县':[0,40],
        //     '什邡市':[-36,0]
        // },
        data:[],
        markLine : {
            symbolSize : 1,
            smooth:true,
            effect : {
                show: true,
                scaleSize: 1,
                period: 50,
                // color: '#fff',
                shadowBlur: 10
            },
            itemStyle : {
                normal: {
                    label:{show:false},
                    borderWidth:1,
                    lineStyle: {
                        type: 'solid',
                        shadowBlur: 10,
                        // 线条颜色
                        color: '#F08136'
                    }
                }
            },
            data : linePoint
        },
        markPoint : {
            symbol:'emptyCircle',
            symbolSize : function (v){
                return 2 + v/10
            },
            effect : {
                period: 40,
                bounceDistance: 2,
                show: true,
                shadowBlur : 0
            },
            itemStyle:{
                normal:{
                    label:{show:false}
                },
                emphasis: {
                    label:{position:'top'}
                }
            },
            data : seriesMarkPoint
        }
    }
};

var seriesMarkPoint=[
    // {name:'500kV桃乡变电站',value:95},
    // {name:'500kV什邡变电站',value:50},
    // {name:'500kV雅安变电站',value:20},
    // {name:'500kV内江变电站',value:70}
    {name:'500kV复兴站',value:500,itemStyle:{normal:{color:'red'}}}
];
var seriesMarkPoint1=[
    // {name:'220kV桃乡变电站',value:95},
    // {name:'220kV什邡变电站',value:50},
    // {name:'220kV雅安变电站',value:20},
    // {name:'220kV内江变电站',value:70}
];
var linePoint=[
    // [{name:'500kV尖山变电站', smoothness:0.2},{name:'500kV桃乡变电站',value:5}],
    // [{name:'500kV尖山变电站', smoothness:0.2},{name:'500kV什邡变电站',value:30}],
    // [{name:'500kV尖山变电站', smoothness:0.2},{name:'500kV雅安变电站',value:50}],
    // [{name:'500kV尖山变电站'},{name:'500kV内江变电站',value:70}]
];
var linePoint1=[
    // [{name:'220kV尖山变电站', smoothness:0.2},{name:'220kV桃乡变电站',value:5}],
    // [{name:'220kV尖山变电站', smoothness:0.2},{name:'220kV什邡变电站',value:30}],
    // [{name:'220kV尖山变电站', smoothness:0.2},{name:'220kV雅安变电站',value:50}],
    // [{name:'220kV尖山变电站'},{name:'500kV内江变电站',value:70}]
];

var smooth;
var linenametotal = [];

for(var k in linedata){
    smooth = 0.2;
    for(var r=0;r<totalname.length;r++){
        if(totalname[r].indexOf(k)!=-1 && totalname[r].indexOf('500kV')!=-1){
            seriesMarkPoint.push({name:totalname[r],value:100*Math.random()});

        }
        if(totalname[r].indexOf(k)!=-1 && totalname[r].indexOf('220kV')!=-1){
            seriesMarkPoint1.push({name:totalname[r],value:100*Math.random()});
        }
    }

    for(var i=0;i<linedata[k].length;i++){
        var templinedata = '';
        for(var y=0;y<linenametotal.length;y++){
            if(linenametotal[y] == linedata[k][i][1]){
                templinedata = linedata[k][i][1]
            }
        }
        if(templinedata == ''){
            linenametotal.push(linedata[k][i][1]);
            if(geocoord[linedata[k][i][2]] !=undefined && geocoord[linedata[k][i][3]] !=undefined){
                var val = 10;
                //if(pmudata[linedata[k][i][1]]!=undefined){
                //    val = pmudata[linedata[k][i][1]][0]["值"];
                //}
                linePoint.push([{name:linedata[k][i][2], linename:linedata[k][i][1], smoothness:smooth},{name:linedata[k][i][3],value:val}]);

                smooth +=0.1;
            }else if(geocoord[linedata[k][i][2]] !=undefined && geocoord[linedata[k][i][3]] ==undefined){
                linePoint.push([{name:k, linename:linedata[k][i][1], smoothness:smooth},{name:linedata[k][i][2],value:10}]);
            }
        }

    }

}

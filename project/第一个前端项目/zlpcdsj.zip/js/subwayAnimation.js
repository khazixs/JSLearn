window.onload = function(){

    let oDivMap = document.getElementById('map');
    creatCurrentData()
    creatShakeData();



    let newTimer= setInterval(function () {
        number1 += 1;//设置电流图刷新一次更新的数据数
      creatCurrentData()
  },1000);//5000ms刷新一次



  let newTimer1= setInterval(function () {
      number2 += 1;//设置振动图刷新一次更新的数据数
    creatShakeData();
},500);//1000ms刷新一次


let a = '';

    oDivMap.onclick = function(){
      number2 = Math.ceil(Math.random()*2000);
          if(nowData['data']['name'] != a && nowData['data']['name'] != undefined){
            powerName = nowData['data']['name'];

            // console.log(nowData)
            // console.log(powerName)
            // nowData['color'] = 'purple';
            option1.title.text = powerName + '当前时间十分钟以内时间电流曲线';
            option2.title.text = powerName + '当前时间两分钟以内时间震动曲线';
            creatCurrentData();
            creatShakeData();
            a = powerName;
          }

    }

function creatCurrentData(){
// console.log(params);
let currentArray1 = [];
let timeArray1 = [];
let nowValue1 = [];
let nowValue2 = [];
for (k in timeCurrent1){
  // console.log(k)
  // console.log(timeCurrent[k]['name'])
  if(timeCurrent1[k]['name'] == powerName){
    if(number1 < 2980){
      for(let i = number1 ;i < (number1+120);i++){
          currentArray1.push(timeCurrent1[k]['current'][i])
      }
    }else{
      number1 = 0;
      for(let i = number1 ;i < (number1+120);i++){
          currentArray1.push(timeCurrent1[k]['current'][i])
      }
    }
  }else{
    // console.log(111)

    // console.log(powerName)
    // console.log('ann'+timeCurrent1[0]['current'][number1+119])
    // console.log('now'+currentArray1[119])
    currentArray = currentArray;
    timeArray = timeArray;
  }
}
let timer = new Date();
let hour = timer.getHours();
let minutes = timer.getMinutes();
let seconds = timer.getSeconds();
let result = hour.toString() + addZero(minutes) + addZero(seconds);
result = parseInt(result);
for(let i = (result - 120);i < result;i++){
  timeArray1.push(i);
}
// for(let i = 110;i<120;i++){
//   avarageCurrent = avarageCurrent+parseFloat(currentArray1[i]);
// }
// avarageCurrent = (avarageCurrent/10)*100;
for(let i=0;i<7;i++){
  // console.log('aa'+ timeCurrent1[0]['current'][number1+119]*100)
    nowValue1[i] = timeCurrent1[i]['current'][number1+119]*100;
    if(nowValue1[i]<=6){
      nowValue2[i] = 4
      // console.log(1)
    }else if(6<nowValue1[i]&&nowValue1[i]<=13){
      nowValue2[i] = 5
        // console.log(2)
    }else if(13<nowValue1[i]&&nowValue1[i]<=25){
        nowValue2[i] = 6
        // console.log(3)
    }else if(25<nowValue1[i]&&nowValue1[i]<=50){
        nowValue2[i] = 7
        // console.log(4)
    }else if(50<nowValue1[i]&&nowValue1[i]<=80){
      nowValue2[i] = 8
    }else if(80<nowValue1[i]&&nowValue1[i]<=130){
      nowValue2[i] = 9
    }else{
      nowValue2[i] = 10
    }

}
// console.log("nnn"+nowValue1[0]/100)
color1 = nowColor(nowValue1[0]);
color2 = nowColor(nowValue1[1]);
color3 = nowColor(nowValue1[2]);
color4 = nowColor(nowValue1[3]);
color5 = nowColor(nowValue1[4]);
color6 = nowColor(nowValue1[5]);
color7 = nowColor(nowValue1[6]);

nowValue = nowValue2;
timeArray = timeArray1;
currentArray = currentArray1


option['series'][1]['itemStyle']['normal']['color'] = color1;
option.series[2].itemStyle.normal.color = color2;
option.series[3].itemStyle.normal.color = color3;
option.series[4].itemStyle.normal.color = color4;
option.series[5].itemStyle.normal.color = color5;
option.series[6].itemStyle.normal.color = color6;
option.series[7].itemStyle.normal.color = color7;

for(let i = 0;i<nowValue.length;i++){
  option.series[i+1].data[0].value[2] = nowValue[i];
}
// console.log(option['series'][1].data)
option1.xAxis.data=timeArray;
option1.series[0].data = currentArray;
lineChart.setOption(option1);
myChart.setOption(option);
}




function nowColor(avarageCurrent){
  let nowColor = '';
  if(avarageCurrent<=6){
    nowColor = colorValue[0]
    // console.log(1)
  }else if(6<avarageCurrent&&avarageCurrent<=13){
      nowColor = colorValue[1]
      // console.log(2)
  }else if(13<avarageCurrent&&avarageCurrent<=25){
      nowColor = colorValue[2]
      // console.log(3)
  }else if(25<avarageCurrent&&avarageCurrent<=50){
      nowColor = colorValue[3]
      // console.log(4)
  }else if(50<avarageCurrent&&avarageCurrent<=80){
    nowColor = colorValue[4]
  }else if(80<avarageCurrent&&avarageCurrent<=130){
      nowColor = colorValue[5]
  }else{
      nowColor = colorValue[6]
  }
  return nowColor
}


function creatShakeData(){
if(number2>=60000){
number2 = 0;
}
let shakeArray1 = [];
let timeArray1 = [];
for(let i = number2;i<number2 + 120;i++){
shakeArray1.push(shake[i]);
}
let timer = new Date();
let hour = timer.getHours();
let minutes = timer.getMinutes();
let seconds = timer.getSeconds();
let result = hour.toString() + addZero(minutes) + addZero(seconds);
result = parseInt(result);
for(let i = (result - 120);i < result;i++){
timeArray1.push(i);
}
timeArray = timeArray1;
shakeArray = shakeArray1;
option2.xAxis.data=timeArray;
option2.series[0].data = shakeArray;
histogram.setOption(option2);

}

function addZero(value) {
    if (value < 10) {
        return "0" + value
    } else {
        return '' + value
    }
  }
}

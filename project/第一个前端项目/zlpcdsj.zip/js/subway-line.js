


var subMarkPoint=[
    // {name:'500kV桃乡变电站',value:95},
    // {name:'500kV什邡变电站',value:50},
    // {name:'500kV雅安变电站',value:20},
    // {name:'500kV内江变电站',value:70}
    {name:'500kv复兴站',value:500}
];

var subLinePoint=[
    // [{name:'500kV尖山变电站', smoothness:0.2},{name:'500kV桃乡变电站',value:5}],
    // [{name:'500kV尖山变电站', smoothness:0.2},{name:'500kV什邡变电站',value:30}],
    // [{name:'500kV尖山变电站', smoothness:0.2},{name:'500kV雅安变电站',value:50}],
    // [{name:'500kV尖山变电站'},{name:'500kV内江变电站',value:70}]
];
var geo = {

}
subLinePoint = sublines

for(let i=0; i<substates.length; i++){
    subMarkPoint.push({name:substates[i]['name'], value:10})
    geo[substates[i]['name']] = substates[i]['gps'];
}
console.log(geo)
console.log(subMarkPoint)
console.log(subLinePoint)
//地图点部分
function subMapSeries(seriesName,subMarkPoint,subLinePoint){

    return {
        name:seriesName,
        type:'map',
        mapType:'湖南',
        hoverable:false,
        roam:true,
        mapLocation:{x:"center",y:'center'},

        itemStyle: {
            normal: {
                label:{
                    show:true,
                    textStyle:{
                        // color:'#ffffff',
                        fontFamily:"Microsoft Yahei"
                    }
                },
                // 地图边框
                // borderColor: 'rgba(64,224,208,1)',
                // borderColor: '#ddfc52',
                areaStyle:{
                    // color: 'rgba(0,0,0,1)'
                }
            },
            emphasis: {
                label:{
                    show:false,
                    textStyle:{
                        // color:'#02DF82',
                        fontFamily:"Microsoft Yahei"
                    }
                },
                borderColor: 'rgba(255,255,255,1)',
                areaStyle:{
                    // color: 'rgba(0, 0, 0, 0.9)'
                }
            }
        },
        geoCoord:geo,
        // // 文本位置修正.
        // textFixed : {
        //     '崇州市' : [0, -50],
        //     '达县':[0,40],
        //     '什邡市':[-36,0]
        // },
        data:[],
        markLine : {
            symbolSize : 1,
            smooth:true,
            effect : {
                show: true,
                scaleSize: 1,
                period: 50,
                // color: '#fff',
                shadowBlur: 10
            },
            itemStyle : {
                normal: {
                    label:{show:false},
                    borderWidth:1,
                    lineStyle: {
                        type: 'solid',
                        shadowBlur: 10,
                        // 线条颜色
                        color: '#000'
                    }
                }
            },
            data : subLinePoint
        },
        markPoint : {
            symbol:'emptyCircle',
            symbolSize : function (v){
                return 2 + v/10
            },
            effect : {
                period: 40,
                bounceDistance: 2,
                show: true,
                shadowBlur : 0
            },
            itemStyle:{
                normal:{
                    label:{show:false}
                },
                emphasis: {
                    label:{position:'top'}
                }
            },
            data : subMarkPoint
        }
    }
};